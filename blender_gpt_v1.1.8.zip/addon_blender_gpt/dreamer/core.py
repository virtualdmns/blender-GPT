import json
import random
import math
import os
import traceback
from typing import Dict, List, Union, Tuple

class Dreamer:
    """
    The Dreamer system breaks down scene requests into logical primitive components
    with proper spatial relationships and attachment points.
    """
    
    def __init__(self):
        self.debug = True
        print("\n=== Initializing Dreamer System ===")
        
        # Sacred geometry constants
        self.PHI = (1 + math.sqrt(5)) / 2  # Golden ratio
        self.FIBONACCI = [1, 1, 2, 3, 5, 8, 13, 21, 34, 55]  # Fibonacci sequence
        self.PLATONIC_SOLIDS = {
            "tetrahedron": 4,
            "cube": 6,
            "octahedron": 8,
            "dodecahedron": 12,
            "icosahedron": 20
        }
        
        # Initialize error handling
        self.errors = []
        self.warnings = []
        
        try:
            # Load reference decompositions
            print("Loading reference decompositions...")
            self.reference_decompositions = self._load_reference_decompositions()
            if not self.reference_decompositions:
                self.warnings.append("No reference decompositions loaded")
            else:
                print(f"Loaded {len(self.reference_decompositions)} reference decompositions")
            
            # Initialize pattern generators
            print("Initializing pattern generators...")
            self.pattern_generators = {
                "growth": self._generate_growth_pattern,
                "fractal": self._generate_fractal_pattern,
                "noise": self._generate_noise_pattern,
                "sacred": self._generate_sacred_pattern,
                "chaos": self._generate_chaos_pattern,
                "flow": self._generate_flow_pattern,
                "dissolve": self._generate_dissolve_pattern,
                "emotional": self._generate_emotional_pattern
            }
            
            # Validate pattern generators
            for name, func in self.pattern_generators.items():
                if not callable(func):
                    self.errors.append(f"Invalid pattern generator: {name}")
            
            # Natural pattern generators
            self.patterns = {
                "growth": self._generate_growth_pattern,
                "fractal": self._generate_fractal_pattern,
                "noise": self._generate_noise_pattern,
                "sacred": self._generate_sacred_pattern,
                "chaos": self._generate_chaos_pattern,
                "flow": self._generate_flow_pattern,
                "dissolve": self._generate_dissolve_pattern,
                "metamorphosis": self._generate_metamorphosis_pattern,
                "entropy": self._generate_entropy_pattern,
                "infinity": self._generate_infinity_pattern
            }
            
            # Abstract concept mappings
            self.abstract_concepts = {
                # Emotional & Psychological Concepts
                "freedom": {
                    "patterns": ["flow", "growth"],
                    "elements": ["bird", "cage", "sky"],
                    "geometry": "spiral",
                    "mood": "liberating",
                    "lighting": {"type": "warm", "color": [1.0, 0.9, 0.7], "intensity": 1.2}
                },
                "loneliness": {
                    "patterns": ["noise", "dissolve"],
                    "elements": ["bench", "road", "figure"],
                    "geometry": "empty",
                    "mood": "isolating",
                    "lighting": {"type": "cold", "color": [0.7, 0.8, 1.0], "intensity": 0.5}
                },
                "love": {
                    "patterns": ["flow", "sacred"],
                    "elements": ["vines", "clearing", "light"],
                    "geometry": "golden_ratio",
                    "mood": "warm",
                    "lighting": {"type": "soft", "color": [1.0, 0.8, 0.8], "intensity": 0.8}
                },
                "fear": {
                    "patterns": ["chaos", "noise"],
                    "elements": ["shadow", "branches", "darkness"],
                    "geometry": "distorted",
                    "mood": "tense",
                    "lighting": {"type": "harsh", "color": [0.8, 0.7, 0.7], "intensity": 1.5, "tint": [0.2, 0.0, 0.0]}
                },
                "hope": {
                    "patterns": ["growth", "flow"],
                    "elements": ["sunlight", "bird", "flower"],
                    "geometry": "ascending",
                    "mood": "uplifting",
                    "lighting": {"type": "warm", "color": [1.0, 0.9, 0.7], "intensity": 1.2}
                },
                "chaos": {
                    "patterns": ["chaos", "noise"],
                    "elements": ["explosion", "glitch", "fragments"],
                    "geometry": "fractal",
                    "mood": "energetic",
                    "lighting": {"type": "harsh", "color": [0.8, 0.7, 0.7], "intensity": 1.5}
                },
                "peace": {
                    "patterns": ["flow", "sacred"],
                    "elements": ["lake", "meditation", "sunrise"],
                    "geometry": "balanced",
                    "mood": "serene",
                    "lighting": {"type": "soft", "color": [0.8, 0.9, 1.0], "intensity": 0.8}
                },
                "time": {
                    "patterns": ["flow", "dissolve"],
                    "elements": ["clock", "sand", "decay"],
                    "geometry": "spiral",
                    "mood": "contemplative",
                    "lighting": {"type": "soft", "color": [0.7, 0.8, 0.9], "intensity": 0.7}
                },
                "death": {
                    "patterns": ["dissolve", "noise"],
                    "elements": ["tree", "candle", "darkness"],
                    "geometry": "descending",
                    "mood": "somber",
                    "lighting": {"type": "cold", "color": [0.5, 0.5, 0.6], "intensity": 0.3}
                },
                "rebirth": {
                    "patterns": ["growth", "flow"],
                    "elements": ["phoenix", "flowers", "ashes"],
                    "geometry": "spiral",
                    "mood": "renewing",
                    "lighting": {"type": "warm", "color": [1.0, 0.9, 0.7], "intensity": 1.2}
                },
                
                # Philosophical Concepts
                "infinity": {
                    "patterns": ["infinity", "sacred"],
                    "elements": ["mirror", "portal", "void"],
                    "geometry": "recursive",
                    "mood": "transcendent",
                    "lighting": {"type": "ethereal", "color": [0.8, 0.8, 1.0], "intensity": 1.0}
                },
                "entropy": {
                    "patterns": ["entropy", "dissolve"],
                    "elements": ["dust", "decay", "fragments"],
                    "geometry": "disordered",
                    "mood": "decaying",
                    "lighting": {"type": "cold", "color": [0.7, 0.7, 0.8], "intensity": 0.5}
                },
                "metamorphosis": {
                    "patterns": ["metamorphosis", "flow"],
                    "elements": ["cocoon", "butterfly", "transformation"],
                    "geometry": "morphing",
                    "mood": "evolving",
                    "lighting": {"type": "dynamic", "color": [0.9, 0.8, 0.9], "intensity": 1.0}
                },
                "consciousness": {
                    "patterns": ["fractal", "flow"],
                    "elements": ["brain", "neural", "light"],
                    "geometry": "neural",
                    "mood": "aware",
                    "lighting": {"type": "ethereal", "color": [0.8, 0.9, 1.0], "intensity": 0.8}
                },
                "reality": {
                    "patterns": ["fractal", "sacred"],
                    "elements": ["mirror", "void", "code"],
                    "geometry": "layered",
                    "mood": "profound",
                    "lighting": {"type": "ethereal", "color": [0.9, 0.9, 1.0], "intensity": 1.0}
                }
            }
            
            # Natural phenomena mappings
            self.natural_phenomena = {
                "seasons": {
                    "patterns": ["flow", "growth"],
                    "elements": ["tree", "leaves", "snow"],
                    "geometry": "cycle",
                    "mood": "changing"
                },
                "storm": {
                    "patterns": ["chaos", "noise"],
                    "elements": ["clouds", "lightning", "rain"],
                    "geometry": "dynamic",
                    "mood": "powerful"
                },
                "ocean": {
                    "patterns": ["flow", "noise"],
                    "elements": ["waves", "water", "horizon"],
                    "geometry": "wave",
                    "mood": "peaceful"
                },
                "space": {
                    "patterns": ["sacred", "noise"],
                    "elements": ["stars", "galaxies", "void"],
                    "geometry": "infinite",
                    "mood": "vast"
                }
            }
            
            # Define conceptual mappings
            self.concept_mappings = {
                "identity": {
                    "mood": "contemplative",
                    "objects": ["mirror", "crystal", "portal", "nebula", "fractal"],
                    "composition": {
                        "density": "low",
                        "variation": "high",
                        "layers": ["ground", "mid", "ethereal"]
                    },
                    "atmosphere": {
                        "lighting": "ethereal",
                        "time_of_day": "timeless",
                        "mood": "philosophical"
                    }
                },
                "forest": {
                    "mood": "serene",
                    "objects": ["tall_tree", "small_tree", "bush", "rock", "mushroom", "grass"],
                    "composition": {
                        "density": "high",
                        "variation": "high",
                        "layers": ["ground", "understory", "canopy"]
                    },
                    "atmosphere": {
                        "lighting": "dappled",
                        "time_of_day": "morning",
                        "mood": "mystical"
                    }
                },
                "city": {
                    "mood": "energetic",
                    "objects": ["building", "street", "car", "person", "lamp_post", "bench"],
                    "composition": {
                        "density": "high",
                        "variation": "medium",
                        "layers": ["ground", "mid", "high"]
                    },
                    "atmosphere": {
                        "lighting": "artificial",
                        "time_of_day": "night",
                        "mood": "bustling"
                    }
                },
                "baby": {
                    "positive": {
                        "mood": "gentle",
                        "objects": ["crib", "teddy_bear", "rattle", "blanket", "mobile"],
                        "composition": {
                            "density": "low",
                            "variation": "medium",
                            "layers": ["ground", "mid"]
                        },
                        "atmosphere": {
                            "lighting": "soft",
                            "time_of_day": "day",
                            "mood": "peaceful"
                        }
                    },
                    "negative": {
                        "mood": "haunting",
                        "objects": ["empty_crib", "broken_toy", "doll", "shadow", "mirror"],
                        "composition": {
                            "density": "low",
                            "variation": "high",
                            "layers": ["ground", "mid", "void"]
                        },
                        "atmosphere": {
                            "lighting": "dim",
                            "time_of_day": "night",
                            "mood": "unsettling"
                        }
                    }
                },
                "lsd": {
                    "mood": "trippy",
                    "objects": ["psychedelic_plant", "crystal", "fractal", "nebula", "portal"],
                    "composition": {
                        "density": "medium",
                        "variation": "extreme",
                        "layers": ["ground", "mid", "high", "space"]
                    },
                    "atmosphere": {
                        "lighting": "neon",
                        "time_of_day": "eternal",
                        "mood": "surreal"
                    }
                }
            }
            
            print("Dreamer system initialized successfully")
            
        except Exception as e:
            self.errors.append(f"Initialization error: {str(e)}")
            print(f"Error during initialization: {str(e)}")
    
    def process_request(self, prompt: str) -> Dict:
        """Process a user's scene request into a structured vision"""
        if not prompt or not isinstance(prompt, str):
            return {
                "role": "assistant",
                "content": {
                    "error": "Invalid prompt provided",
                    "scene_analysis": None,
                    "object_breakdowns": None
                }
            }
            
        print(f"\n=== Processing Request: {prompt} ===")
        
        try:
            # First, try to understand the conceptual meaning
            print("\nInterpreting concept...")
            concept = self._interpret_concept(prompt)
            if not concept:
                raise ValueError("Failed to interpret concept")
            print(f"Interpreted concept: {json.dumps(concept, indent=2)}")
            
            print("\nAnalyzing atmosphere...")
            atmosphere = self._analyze_atmosphere(prompt, concept)
            print(f"Atmosphere analysis: {json.dumps(atmosphere, indent=2)}")
            
            print("\nAnalyzing composition...")
            composition = self._analyze_composition(prompt, concept)
            print(f"Composition analysis: {json.dumps(composition, indent=2)}")
            
            print("\nIdentifying objects...")
            objects = self._identify_objects(prompt, concept)
            if not objects:
                self.warnings.append("No objects identified")
            print(f"Identified objects: {objects}")
            
            # Break down each object with variations based on concept
            print("\nDecomposing objects...")
            object_breakdowns = {}
            for obj in objects:
                print(f"\nDecomposing object: {obj}")
                try:
                    object_breakdowns[obj] = self._decompose_object(obj, concept)
                    print(f"Decomposition: {json.dumps(object_breakdowns[obj], indent=2)}")
                except Exception as e:
                    self.errors.append(f"Error decomposing {obj}: {str(e)}")
                    object_breakdowns[obj] = self._get_default_decomposition(obj)
            
            # Format the response
            response = {
                "role": "assistant",
                "content": {
                    "scene_analysis": {
                        "atmosphere": atmosphere,
                        "objects_identified": objects
                    },
                    "object_breakdowns": {
                        obj: {
                            "primary": decomp["primary_form"]["primitive"],
                            "secondary_forms": len(decomp["secondary_forms"]),
                            "details": len(decomp["tertiary_details"])
                        }
                        for obj, decomp in object_breakdowns.items()
                    }
                }
            }
            
            # Add any warnings or errors
            if self.warnings:
                response["content"]["warnings"] = self.warnings
            if self.errors:
                response["content"]["errors"] = self.errors
            
            print("\n=== Request Processing Complete ===")
            return response
            
        except Exception as e:
            error_msg = f"Error processing request: {str(e)}"
            print(error_msg)
            self.errors.append(error_msg)
            return {
                "role": "assistant",
                "content": {
                    "error": error_msg,
                    "scene_analysis": None,
                    "object_breakdowns": None,
                    "errors": self.errors
                }
            }
    
    def _get_default_decomposition(self, object_name: str) -> Dict:
        """Provide a default decomposition for unknown objects"""
        return {
            "primary_form": {
                "primitive": "CUBE",
                "name": object_name,
                "dimensions": {"size": 1.0},
                "variation": 0.2
            },
            "secondary_forms": [],
            "tertiary_details": ["basic_texture"]
        }
    
    def _generate_growth_pattern(self, size: float, complexity: float) -> List[Dict]:
        """Generate organic growth patterns using L-systems and Fibonacci spirals"""
        pattern = []
        angle = 2 * math.pi * self.PHI  # Golden angle
        radius = size * 0.1
        
        for i in range(int(complexity * 10)):
            # Fibonacci spiral growth
            radius *= 1.1
            x = radius * math.cos(i * angle)
            y = radius * math.sin(i * angle)
            z = i * 0.1
            
            pattern.append({
                "position": [x, y, z],
                "scale": radius * 0.2,
                "rotation": [i * angle, 0, 0]
            })
            
        return pattern
    
    def _generate_fractal_pattern(self, size: float, complexity: float) -> List[Dict]:
        """Generate fractal patterns using recursive subdivision"""
        pattern = []
        
        def subdivide(pos: List[float], size: float, depth: int):
            if depth <= 0:
                pattern.append({
                    "position": pos,
                    "scale": size,
                    "rotation": [random.uniform(0, math.pi), 0, 0]
                })
                return
                
            # Recursive subdivision with golden ratio proportions
            new_size = size / self.PHI
            for i in range(3):
                angle = 2 * math.pi * i / 3
                new_pos = [
                    pos[0] + new_size * math.cos(angle),
                    pos[1] + new_size * math.sin(angle),
                    pos[2]
                ]
                subdivide(new_pos, new_size, depth - 1)
        
        subdivide([0, 0, 0], size, int(complexity * 5))
        return pattern
    
    def _generate_noise_pattern(self, size: float, complexity: float) -> List[Dict]:
        """Generate natural-looking patterns using noise functions"""
        pattern = []
        points = int(complexity * 20)
        
        for i in range(points):
            # 3D noise-based position
            x = random.uniform(-size, size)
            y = random.uniform(-size, size)
            z = random.uniform(-size * 0.5, size * 0.5)
            
            # Noise-based scale and rotation
            scale = size * (0.1 + 0.2 * random.random())
            rotation = [
                random.uniform(0, math.pi),
                random.uniform(0, math.pi),
                random.uniform(0, math.pi)
            ]
            
            pattern.append({
                "position": [x, y, z],
                "scale": scale,
                "rotation": rotation
            })
            
        return pattern
    
    def _generate_sacred_pattern(self, size: float, complexity: float) -> List[Dict]:
        """Generate patterns based on sacred geometry principles"""
        pattern = []
        
        # Platonic solid vertices
        vertices = {
            "tetrahedron": [
                [0, 0, 1], [1, 0, 0], [0, 1, 0], [-1, 0, 0]
            ],
            "octahedron": [
                [0, 0, 1], [1, 0, 0], [0, 1, 0], [-1, 0, 0],
                [0, 0, -1], [-1, 0, 0], [0, -1, 0], [1, 0, 0]
            ],
            "icosahedron": [
                [0, 0, 1], [1, 0, 0], [0, 1, 0], [-1, 0, 0],
                [0, 0, -1], [-1, 0, 0], [0, -1, 0], [1, 0, 0],
                [self.PHI, 1/self.PHI, 0], [-self.PHI, 1/self.PHI, 0],
                [self.PHI, -1/self.PHI, 0], [-self.PHI, -1/self.PHI, 0]
            ]
        }
        
        # Generate pattern based on sacred geometry
        for i in range(int(complexity * 5)):
            # Select a platonic solid
            solid = random.choice(list(vertices.keys()))
            verts = vertices[solid]
            
            # Create pattern elements at vertices
            for vert in verts:
                pos = [v * size for v in vert]
                pattern.append({
                    "position": pos,
                    "scale": size * 0.2,
                    "rotation": [random.uniform(0, math.pi), 0, 0]
                })
        
        return pattern
    
    def _generate_chaos_pattern(self, size: float, complexity: float) -> List[Dict]:
        """Generate chaotic, glitch-like patterns"""
        pattern = []
        points = int(complexity * 15)
        
        for i in range(points):
            # Random glitch positions
            x = random.uniform(-size, size)
            y = random.uniform(-size, size)
            z = random.uniform(-size * 0.5, size * 0.5)
            
            # Glitch-like scale and rotation
            scale = size * random.uniform(0.1, 0.5)
            rotation = [
                random.uniform(0, math.pi * 2),
                random.uniform(0, math.pi * 2),
                random.uniform(0, math.pi * 2)
            ]
            
            pattern.append({
                "position": [x, y, z],
                "scale": scale,
                "rotation": rotation,
                "glitch": random.random() > 0.7  # Some elements are glitched
            })
            
        return pattern
    
    def _generate_flow_pattern(self, size: float, complexity: float) -> List[Dict]:
        """Generate flowing, organic patterns"""
        pattern = []
        points = int(complexity * 10)
        
        for i in range(points):
            # Flow-based positions using sine waves
            t = i / points
            x = size * math.sin(t * math.pi * 2)
            y = size * math.cos(t * math.pi * 2)
            z = size * 0.5 * math.sin(t * math.pi)
            
            # Smooth scale and rotation
            scale = size * (0.2 + 0.3 * math.sin(t * math.pi * 4))
            rotation = [t * math.pi * 2, 0, 0]
            
            pattern.append({
                "position": [x, y, z],
                "scale": scale,
                "rotation": rotation,
                "flow": True
            })
            
        return pattern
    
    def _generate_dissolve_pattern(self, size: float, complexity: float) -> List[Dict]:
        """Generate dissolving, fading patterns"""
        pattern = []
        points = int(complexity * 8)
        
        for i in range(points):
            # Dissolving positions
            t = i / points
            x = size * (1 - t) * math.cos(t * math.pi * 2)
            y = size * (1 - t) * math.sin(t * math.pi * 2)
            z = size * 0.5 * (1 - t)
            
            # Fading scale and rotation
            scale = size * (1 - t) * 0.3
            rotation = [t * math.pi, 0, 0]
            
            pattern.append({
                "position": [x, y, z],
                "scale": scale,
                "rotation": rotation,
                "fade": t
            })
            
        return pattern
    
    def _generate_metamorphosis_pattern(self, size: float, complexity: float) -> List[Dict]:
        """Generate patterns that represent transformation and change"""
        pattern = []
        points = int(complexity * 12)
        
        for i in range(points):
            t = i / points
            # Create a morphing spiral
            angle = t * math.pi * 4
            radius = size * (0.2 + 0.3 * math.sin(t * math.pi * 2))
            x = radius * math.cos(angle)
            y = radius * math.sin(angle)
            z = size * 0.5 * math.sin(t * math.pi)
            
            # Morphing scale and rotation
            scale = size * (0.2 + 0.3 * math.sin(t * math.pi * 3))
            rotation = [t * math.pi * 2, t * math.pi, 0]
            
            pattern.append({
                "position": [x, y, z],
                "scale": scale,
                "rotation": rotation,
                "morph": t
            })
            
        return self._apply_physical_constraints(pattern)
    
    def _generate_entropy_pattern(self, size: float, complexity: float) -> List[Dict]:
        """Generate patterns that represent decay and disorder"""
        pattern = []
        points = int(complexity * 15)
        
        for i in range(points):
            t = i / points
            # Create disordered positions with increasing randomness
            x = size * (1 - t) * random.uniform(-1, 1)
            y = size * (1 - t) * random.uniform(-1, 1)
            z = size * 0.5 * (1 - t) * random.uniform(0, 1)
            
            # Decaying scale and rotation
            scale = size * (1 - t) * random.uniform(0.1, 0.5)
            rotation = [
                random.uniform(0, math.pi * 2),
                random.uniform(0, math.pi * 2),
                random.uniform(0, math.pi * 2)
            ]
            
            pattern.append({
                "position": [x, y, z],
                "scale": scale,
                "rotation": rotation,
                "decay": t
            })
            
        return self._apply_physical_constraints(pattern)
    
    def _generate_infinity_pattern(self, size: float, complexity: float) -> List[Dict]:
        """Generate patterns that represent infinite recursion and self-similarity"""
        pattern = []
        points = int(complexity * 10)
        
        def recursive_placement(pos: List[float], size: float, depth: int):
            if depth <= 0:
                pattern.append({
                    "position": pos,
                    "scale": size,
                    "rotation": [random.uniform(0, math.pi), 0, 0]
                })
                return
                
            # Create self-similar placements
            for i in range(3):
                angle = 2 * math.pi * i / 3
                new_pos = [
                    pos[0] + size * math.cos(angle),
                    pos[1] + size * math.sin(angle),
                    pos[2]
                ]
                recursive_placement(new_pos, size / self.PHI, depth - 1)
        
        recursive_placement([0, 0, 0], size, int(complexity * 3))
        return self._apply_physical_constraints(pattern)
    
    def _generate_emotional_pattern(self, size: float, complexity: float, mood: str) -> List[Dict]:
        """Generate patterns that evoke specific emotional responses"""
        pattern = []
        points = int(complexity * 12)
        
        # Emotional pattern parameters
        mood_params = {
            "joy": {
                "spiral": True,
                "expansion": 1.2,
                "brightness": 1.5,
                "flow": "upward",
                "symmetry": "radial"
            },
            "sadness": {
                "spiral": False,
                "expansion": 0.8,
                "brightness": 0.5,
                "flow": "downward",
                "symmetry": "broken"
            },
            "fear": {
                "spiral": True,
                "expansion": 1.5,
                "brightness": 0.3,
                "flow": "chaotic",
                "symmetry": "distorted"
            },
            "peace": {
                "spiral": False,
                "expansion": 1.0,
                "brightness": 1.0,
                "flow": "gentle",
                "symmetry": "balanced"
            },
            "anger": {
                "spiral": True,
                "expansion": 2.0,
                "brightness": 1.8,
                "flow": "violent",
                "symmetry": "fractured"
            },
            "love": {
                "spiral": True,
                "expansion": 1.1,
                "brightness": 1.3,
                "flow": "intertwined",
                "symmetry": "golden"
            }
        }
        
        params = mood_params.get(mood, mood_params["peace"])
        
        for i in range(points):
            t = i / points
            angle = t * math.pi * 4 if params["spiral"] else t * math.pi * 2
            
            # Base position calculation
            radius = size * params["expansion"] * (1 + 0.2 * math.sin(t * math.pi * 2))
            x = radius * math.cos(angle)
            y = radius * math.sin(angle)
            
            # Apply emotional flow
            if params["flow"] == "upward":
                z = size * 0.5 * t
            elif params["flow"] == "downward":
                z = size * 0.5 * (1 - t)
            elif params["flow"] == "chaotic":
                z = size * 0.5 * random.uniform(-1, 1)
            elif params["flow"] == "violent":
                z = size * 0.5 * math.sin(t * math.pi * 8)
            elif params["flow"] == "intertwined":
                z = size * 0.5 * math.sin(t * math.pi * 2)
            else:  # gentle
                z = size * 0.5 * math.sin(t * math.pi)
            
            # Apply emotional symmetry
            if params["symmetry"] == "broken":
                x += random.uniform(-0.2, 0.2) * size
                y += random.uniform(-0.2, 0.2) * size
            elif params["symmetry"] == "distorted":
                x *= (1 + 0.3 * math.sin(t * math.pi * 3))
                y *= (1 + 0.3 * math.cos(t * math.pi * 3))
            elif params["symmetry"] == "fractured":
                x *= (1 + 0.5 * random.uniform(-1, 1))
                y *= (1 + 0.5 * random.uniform(-1, 1))
            elif params["symmetry"] == "golden":
                x *= self.PHI
                y *= self.PHI
            
            # Emotional scale and rotation
            scale = size * (0.2 + 0.3 * math.sin(t * math.pi * 3))
            rotation = [
                t * math.pi * 2,
                t * math.pi * params["expansion"],
                0
            ]
            
            pattern.append({
                "position": [x, y, z],
                "scale": scale,
                "rotation": rotation,
                "brightness": params["brightness"],
                "emotion": mood
            })
            
        return self._apply_physical_constraints(pattern)
    
    def _interpret_concept(self, prompt: str) -> Dict:
        """Interpret the conceptual meaning of the prompt using abstract concepts and natural patterns"""
        try:
            print(f"\nInterpreting concept for prompt: {prompt}")
            prompt_lower = prompt.lower()
            
            # Check for existential/identity questions
            if any(phrase in prompt_lower for phrase in ["who are you", "what are you", "what is this", "who am i", "what am i"]):
                print("Detected existential/identity question")
                return {
                    "type": "identity",
                    "mapping": self.concept_mappings["identity"],
                    "patterns": ["sacred", "fractal"],
                    "elements": self.concept_mappings["identity"]["objects"],
                    "geometry": "sacred",
                    "mood": "contemplative",
                    "complexity": self._apply_complexity_bounds(1.5)
                }
            
            # First check for specific scene concepts
            concept = None
            for key, value in self.concept_mappings.items():
                if key in prompt_lower:
                    print(f"Found specific scene concept: {key}")
                    # Check for emotional context in prompt
                    is_negative = any(word in prompt_lower for word in ["horror", "curse", "bad", "evil", "dark", "scary", "terrifying", "haunting"])
                    is_positive = any(word in prompt_lower for word in ["beautiful", "blessing", "good", "happy", "joy", "peace", "love", "wonderful"])
                    
                    if isinstance(value, dict) and "positive" in value and "negative" in value:
                        print(f"Using {'negative' if is_negative else 'positive'} interpretation")
                        mapping = value["negative"] if is_negative else value["positive"]
                    else:
                        mapping = value
                    
                    concept = {
                        "type": "scene",
                        "mapping": mapping,
                        "patterns": ["flow", "sacred"],  # Default patterns for scenes
                        "elements": mapping["objects"],
                        "geometry": "natural",
                        "mood": mapping["mood"],
                        "complexity": self._apply_complexity_bounds(1.0)
                    }
                    break
            
            # If no scene concept found, check for abstract concepts
            if not concept:
                for key, value in self.abstract_concepts.items():
                    if key in prompt_lower:
                        print(f"Found abstract concept: {key}")
                        concept = {
                            "type": "abstract",
                            "mapping": value,
                            "patterns": value["patterns"],
                            "elements": value["elements"],
                            "geometry": value["geometry"],
                            "mood": value["mood"],
                            "complexity": self._apply_complexity_bounds(1.0)
                        }
                        break
            
            # If still no concept found, check for natural phenomena
            if not concept:
                for key, value in self.natural_phenomena.items():
                    if key in prompt_lower:
                        print(f"Found natural phenomenon: {key}")
                        concept = {
                            "type": "phenomenon",
                            "mapping": value,
                            "patterns": value["patterns"],
                            "elements": value["elements"],
                            "geometry": value["geometry"],
                            "mood": value["mood"],
                            "complexity": self._apply_complexity_bounds(1.0)
                        }
                        break
            
            # If no specific concept found, analyze patterns
            if not concept:
                print("No specific concept found, analyzing patterns...")
                patterns = self._analyze_patterns(prompt_lower)
                print(f"Detected patterns: {patterns}")
                
                concept = {
                    "type": "generative",
                    "patterns": patterns or ["growth", "noise"],  # Default patterns
                    "elements": [],
                    "geometry": "natural",
                    "mood": "neutral",
                    "complexity": self._apply_complexity_bounds(1.0)
                }
            
            # Determine complexity from prompt with bounds
            if "complex" in prompt_lower or "detailed" in prompt_lower:
                print("Increasing complexity due to prompt")
                concept["complexity"] = self._apply_complexity_bounds(2.0)
            elif "simple" in prompt_lower or "basic" in prompt_lower:
                print("Reducing complexity due to prompt")
                concept["complexity"] = self._apply_complexity_bounds(0.5)
            
            print(f"Final concept interpretation: {json.dumps(concept, indent=2)}")
            return concept
            
        except Exception as e:
            self.errors.append(f"Error interpreting concept: {str(e)}")
            return {
                "type": "generative",
                "patterns": ["growth", "noise"],
                "elements": [],
                "geometry": "natural",
                "mood": "neutral",
                "complexity": self._apply_complexity_bounds(1.0)
            }
    
    def _analyze_patterns(self, prompt: str) -> List[str]:
        """Analyze prompt for pattern keywords"""
        patterns = []
        pattern_keywords = {
            "growth": ["growth", "organic", "living"],
            "fractal": ["fractal", "complex", "detailed"],
            "noise": ["noise", "random", "natural"],
            "sacred": ["sacred", "divine", "perfect"],
            "chaos": ["chaos", "destruction", "glitch"],
            "flow": ["flow", "water", "wind"],
            "dissolve": ["dissolve", "fade", "decay"]
        }
        
        for pattern, keywords in pattern_keywords.items():
            if any(word in prompt for word in keywords):
                patterns.append(pattern)
        
        return patterns
    
    def _analyze_atmosphere(self, prompt: str, concept: Dict) -> Dict:
        """Analyze atmospheric conditions from prompt and concept"""
        try:
            prompt_lower = prompt.lower()
            
            # Determine time of day from prompt
            time_of_day = "day"
            if "night" in prompt_lower or "dark" in prompt_lower:
                time_of_day = "night"
            elif "morning" in prompt_lower or "dawn" in prompt_lower:
                time_of_day = "morning"
            elif "evening" in prompt_lower or "dusk" in prompt_lower:
                time_of_day = "evening"
            
            # Determine mood from patterns and concept
            mood = concept.get("mood", "neutral")
            if "growth" in concept["patterns"]:
                mood = "organic"
            if "fractal" in concept["patterns"]:
                mood = "complex"
            if "sacred" in concept["patterns"]:
                mood = "divine"
            
            # Determine lighting based on patterns and mood
            lighting = "natural"
            if "sacred" in concept["patterns"]:
                lighting = "ethereal"
            if "fractal" in concept["patterns"]:
                lighting = "dynamic"
            
            # Calculate intensity based on complexity
            intensity = 1.0
            if concept["complexity"] > 1.5:
                intensity = 1.5
            elif concept["complexity"] < 0.7:
                intensity = 0.7
            
            return {
                "time_of_day": time_of_day,
                "mood": mood,
                "lighting": {
                    "type": lighting,
                    "intensity": intensity,
                    "variation": concept["complexity"] * 0.5
                }
            }
            
        except Exception as e:
            self.errors.append(f"Error analyzing atmosphere: {str(e)}")
            return {
                "time_of_day": "day",
                "mood": "neutral",
                "lighting": {
                    "type": "natural",
                    "intensity": 1.0,
                    "variation": 0.5
                }
            }
    
    def _analyze_composition(self, prompt: str, concept: Dict) -> Dict:
        """Analyze scene composition and layout based on concept"""
        # Generate layers based on patterns and mood
        layers = ["ground"]
        if "growth" in concept["patterns"]:
            layers.extend(["mid", "high"])
        if "fractal" in concept["patterns"]:
            layers.extend(["detail", "micro"])
        if "sacred" in concept["patterns"]:
            layers.extend(["divine", "ethereal"])
            
        # Determine density and arrangement based on mood
        density = "medium"
        arrangement = "balanced"
        
        if concept["mood"] in ["joy", "love", "peace"]:
            density = "medium"
            arrangement = "harmonious"
        elif concept["mood"] in ["fear", "anger"]:
            density = "high"
            arrangement = "chaotic"
        elif concept["mood"] in ["sadness", "loneliness"]:
            density = "low"
            arrangement = "sparse"
            
        # Generate emotional focal points
        focal_points = self._generate_focal_points(concept)
        
        # Apply emotional arrangement to focal points
        for point in focal_points:
            if arrangement == "harmonious":
                # Use golden ratio for harmonious placement
                point["position"][0] *= self.PHI
                point["position"][1] *= self.PHI
            elif arrangement == "chaotic":
                # Add random variation for chaotic placement
                point["position"][0] += random.uniform(-2, 2)
                point["position"][1] += random.uniform(-2, 2)
            elif arrangement == "sparse":
                # Increase distance between points for sparse placement
                point["position"][0] *= 1.5
                point["position"][1] *= 1.5
            
        return {
            "layers": {
                layer: {
                    "height": idx * 2,
                    "density": density,
                    "arrangement": arrangement,
                    "objects": []
                }
                for idx, layer in enumerate(layers)
            },
            "variation": "high" if concept["complexity"] > 1.0 else "medium",
            "focal_points": focal_points,
            "emotional_arrangement": arrangement
        }
    
    def _generate_focal_points(self, concept: Dict) -> List[Dict]:
        """Generate focal points based on concept"""
        num_points = int(concept["complexity"] * 2)
        
        return [
            {
                "position": [
                    random.uniform(-5, 5),
                    random.uniform(-5, 5),
                    random.uniform(-2, 2)
                ],
                "importance": random.uniform(0.7, 1.0)
            }
            for _ in range(num_points)
        ]
    
    def _identify_objects(self, prompt: str, concept: Dict) -> List[str]:
        """Identify required objects from prompt and concept"""
        print(f"\nIdentifying objects for prompt: {prompt}")
        prompt_lower = prompt.lower()
        
        # First check for specific scene concepts
        if "baby" in prompt_lower or "newborn" in prompt_lower:
            print("Detected baby scene")
            return ["crib", "teddy_bear", "rattle", "blanket", "mobile"]
        elif "beach" in prompt_lower:
            print("Detected beach scene")
            return ["wave", "sand", "shell", "palm", "coral"]
        elif "forest" in prompt_lower:
            print("Detected forest scene")
            return ["tall_tree", "small_tree", "bush", "rock", "mushroom", "grass"]
        elif "garden" in prompt_lower:
            print("Detected garden scene")
            return ["flower", "plant", "vine", "grass"]
        elif "city" in prompt_lower:
            print("Detected city scene")
            return ["building", "street", "car", "person", "lamp_post", "bench"]
        elif "crystal" in prompt_lower:
            print("Detected crystal scene")
            return ["crystal", "geode", "shard"]
            
        # If no specific scene found, use pattern-based selection
        print("No specific scene detected, using pattern-based selection")
        object_categories = {
            "growth": ["plant", "flower", "tree", "vine", "grass"],
            "fractal": ["crystal", "geode", "shell", "coral", "star"],
            "noise": ["cloud", "wave", "sand", "rock", "pebble"],
            "sacred": ["mandala", "temple", "altar", "shrine", "monolith"]
        }
        
        selected_objects = []
        
        # Add objects based on patterns
        for pattern in concept["patterns"]:
            if pattern in object_categories:
                num_objects = random.randint(2, 4)
                new_objects = random.sample(object_categories[pattern], num_objects)
                print(f"Adding {num_objects} objects for pattern '{pattern}': {new_objects}")
                selected_objects.extend(new_objects)
        
        # Ensure we have at least some objects
        if not selected_objects:
            print("No objects selected, using defaults")
            selected_objects = ["plant", "rock", "crystal"]
            
        # Scale number of objects based on complexity
        if concept["complexity"] > 1.5:
            print("Doubling objects due to high complexity")
            selected_objects = selected_objects * 2
        elif concept["complexity"] < 0.7:
            print("Reducing objects due to low complexity")
            selected_objects = selected_objects[:3]
            
        print(f"Final object selection: {selected_objects}")
        return selected_objects
    
    def _decompose_object(self, object_name: str, concept: Dict = None) -> Dict:
        """Decompose an object into its primitive forms and details with error handling"""
        try:
            # First check if we have a reference decomposition
            if object_name.lower() in self.reference_decompositions:
                decomp = self.reference_decompositions[object_name.lower()]
            else:
                # Fall back to base decompositions
                decomp = self._get_base_decomposition(object_name)
            
            # Validate decomposition structure
            if not isinstance(decomp, dict):
                raise ValueError(f"Invalid decomposition structure for {object_name}")
            
            # Ensure required fields exist
            required_fields = ["primary_form", "secondary_forms", "tertiary_details"]
            for field in required_fields:
                if field not in decomp:
                    raise ValueError(f"Missing required field {field} in decomposition")
            
            # Apply conceptual variations if available
            if concept:
                decomp = self._apply_conceptual_variations(decomp, concept)
            
            return decomp
            
        except Exception as e:
            self.errors.append(f"Error decomposing {object_name}: {str(e)}")
            return self._get_default_decomposition(object_name)
    
    def _get_base_decomposition(self, object_name: str) -> Dict:
        """Get base decomposition for known objects"""
        base_decompositions = {
            "tall_tree": {
                "primary_form": {
                    "primitive": "CYLINDER",
                    "name": "trunk",
                    "dimensions": {"radius": 0.3, "height": 5.0},
                    "variation": 0.2
                },
                "secondary_forms": [
                    {
                        "primitive": "SPHERE",
                        "name": "crown",
                        "dimensions": {"radius": 2.0},
                        "variation": 0.3
                    }
                ],
                "tertiary_details": ["bark_texture", "leaves", "branches"]
            },
            "small_tree": {
                "primary_form": {
                    "primitive": "CYLINDER",
                    "name": "trunk",
                    "dimensions": {"radius": 0.2, "height": 2.5},
                    "variation": 0.2
                },
                "secondary_forms": [
                    {
                        "primitive": "SPHERE",
                        "name": "foliage",
                        "dimensions": {"radius": 1.2},
                        "variation": 0.3
                    }
                ],
                "tertiary_details": ["bark_texture", "leaf_particles"]
            },
            "bush": {
                "primary_form": {
                    "primitive": "SPHERE",
                    "name": "foliage",
                    "dimensions": {"radius": 0.8},
                    "variation": 0.4
                },
                "secondary_forms": [],
                "tertiary_details": ["leaf_texture"]
            },
            "rock": {
                "primary_form": {
                    "primitive": "ICO_SPHERE",
                    "name": "base",
                    "dimensions": {"radius": 0.5},
                    "variation": 0.5
                },
                "secondary_forms": [],
                "tertiary_details": ["rock_texture", "displacement"]
            },
            "grass": {
                "primary_form": {
                    "primitive": "PLANE",
                    "name": "blade",
                    "dimensions": {"size": 0.1, "height": 0.3},
                    "variation": 0.6
                },
                "secondary_forms": [],
                "tertiary_details": ["transparency", "wind_motion"]
            },
            "mushroom": {
                "primary_form": {
                    "primitive": "CYLINDER",
                    "name": "stem",
                    "dimensions": {"radius": 0.1, "height": 0.3},
                    "variation": 0.2
                },
                "secondary_forms": [
                    {
                        "primitive": "SPHERE",
                        "name": "cap",
                        "dimensions": {"radius": 0.25},
                        "variation": 0.3
                    }
                ],
                "tertiary_details": ["spots", "glow"]
            },
            "building": {
                "primary_form": {
                    "primitive": "CUBE",
                    "name": "main",
                    "dimensions": {"width": 2.0, "height": 4.0, "depth": 2.0},
                    "variation": 0.1
                },
                "secondary_forms": [
                    {
                        "primitive": "CUBE",
                        "name": "windows",
                        "dimensions": {"width": 0.2, "height": 0.2, "depth": 0.1},
                        "variation": 0.2
                    }
                ],
                "tertiary_details": ["glass", "reflection"]
            },
            "car": {
                "primary_form": {
                    "primitive": "CUBE",
                    "name": "body",
                    "dimensions": {"width": 1.5, "height": 0.5, "depth": 0.8},
                    "variation": 0.2
                },
                "secondary_forms": [
                    {
                        "primitive": "CYLINDER",
                        "name": "wheel",
                        "dimensions": {"radius": 0.2, "height": 0.1},
                        "variation": 0.1
                    }
                ],
                "tertiary_details": ["metal", "glass"]
            },
            "person": {
                "primary_form": {
                    "primitive": "CYLINDER",
                    "name": "body",
                    "dimensions": {"radius": 0.2, "height": 1.7},
                    "variation": 0.1
                },
                "secondary_forms": [
                    {
                        "primitive": "SPHERE",
                        "name": "head",
                        "dimensions": {"radius": 0.15},
                        "variation": 0.1
                    }
                ],
                "tertiary_details": ["clothing", "face"]
            },
            "lamp_post": {
                "primary_form": {
                    "primitive": "CYLINDER",
                    "name": "pole",
                    "dimensions": {"radius": 0.1, "height": 3.0},
                    "variation": 0.1
                },
                "secondary_forms": [
                    {
                        "primitive": "SPHERE",
                        "name": "lamp",
                        "dimensions": {"radius": 0.3},
                        "variation": 0.2
                    }
                ],
                "tertiary_details": ["glow", "metal"]
            },
            "bench": {
                "primary_form": {
                    "primitive": "CUBE",
                    "name": "seat",
                    "dimensions": {"width": 1.5, "height": 0.2, "depth": 0.4},
                    "variation": 0.1
                },
                "secondary_forms": [
                    {
                        "primitive": "CYLINDER",
                        "name": "leg",
                        "dimensions": {"radius": 0.05, "height": 0.4},
                        "variation": 0.1
                    }
                ],
                "tertiary_details": ["wood", "metal"]
            },
            "crib": {
                "primary_form": {
                    "primitive": "CUBE",
                    "name": "frame",
                    "dimensions": {"width": 1.0, "height": 0.8, "depth": 0.6},
                    "variation": 0.1
                },
                "secondary_forms": [
                    {
                        "primitive": "CYLINDER",
                        "name": "bar",
                        "dimensions": {"radius": 0.02, "height": 0.6},
                        "variation": 0.1
                    }
                ],
                "tertiary_details": ["wood", "fabric"]
            },
            "teddy_bear": {
                "primary_form": {
                    "primitive": "SPHERE",
                    "name": "body",
                    "dimensions": {"radius": 0.3},
                    "variation": 0.2
                },
                "secondary_forms": [
                    {
                        "primitive": "SPHERE",
                        "name": "head",
                        "dimensions": {"radius": 0.2},
                        "variation": 0.2
                    }
                ],
                "tertiary_details": ["fur", "face"]
            },
            "psychedelic_plant": {
                "primary_form": {
                    "primitive": "CYLINDER",
                    "name": "stem",
                    "dimensions": {"radius": 0.1, "height": 1.0},
                    "variation": 0.3
                },
                "secondary_forms": [
                    {
                        "primitive": "SPHERE",
                        "name": "flower",
                        "dimensions": {"radius": 0.3},
                        "variation": 0.4
                    }
                ],
                "tertiary_details": ["neon_glow", "fractal_pattern"]
            },
            "crystal": {
                "primary_form": {
                    "primitive": "ICO_SPHERE",
                    "name": "base",
                    "dimensions": {"radius": 0.3},
                    "variation": 0.2
                },
                "secondary_forms": [],
                "tertiary_details": ["refraction", "rainbow"]
            },
            "fractal": {
                "primary_form": {
                    "primitive": "CUBE",
                    "name": "base",
                    "dimensions": {"size": 1.0},
                    "variation": 0.5
                },
                "secondary_forms": [],
                "tertiary_details": ["recursive", "neon"]
            },
            "nebula": {
                "primary_form": {
                    "primitive": "SPHERE",
                    "name": "cloud",
                    "dimensions": {"radius": 2.0},
                    "variation": 0.8
                },
                "secondary_forms": [],
                "tertiary_details": ["gas", "stars"]
            },
            "portal": {
                "primary_form": {
                    "primitive": "TORUS",
                    "name": "ring",
                    "dimensions": {"radius": 1.0, "thickness": 0.1},
                    "variation": 0.2
                },
                "secondary_forms": [],
                "tertiary_details": ["energy", "distortion"]
            },
            "wave": {
                "primary_form": {
                    "primitive": "CUBE",
                    "name": "base",
                    "dimensions": {"width": 3.0, "height": 0.5, "depth": 1.0},
                    "variation": 0.4
                },
                "secondary_forms": [
                    {
                        "primitive": "SPHERE",
                        "name": "crest",
                        "dimensions": {"radius": 0.3},
                        "variation": 0.5
                    }
                ],
                "tertiary_details": ["water", "foam", "transparency"]
            },
            "sand": {
                "primary_form": {
                    "primitive": "PLANE",
                    "name": "ground",
                    "dimensions": {"width": 10.0, "height": 10.0},
                    "variation": 0.3
                },
                "secondary_forms": [
                    {
                        "primitive": "SPHERE",
                        "name": "dune",
                        "dimensions": {"radius": 0.5},
                        "variation": 0.4
                    }
                ],
                "tertiary_details": ["texture", "displacement"]
            },
            "shell": {
                "primary_form": {
                    "primitive": "SPHERE",
                    "name": "base",
                    "dimensions": {"radius": 0.2},
                    "variation": 0.3
                },
                "secondary_forms": [
                    {
                        "primitive": "CUBE",
                        "name": "spiral",
                        "dimensions": {"size": 0.1},
                        "variation": 0.4
                    }
                ],
                "tertiary_details": ["iridescence", "pattern"]
            },
            "palm": {
                "primary_form": {
                    "primitive": "CYLINDER",
                    "name": "trunk",
                    "dimensions": {"radius": 0.2, "height": 3.0},
                    "variation": 0.3
                },
                "secondary_forms": [
                    {
                        "primitive": "SPHERE",
                        "name": "frond",
                        "dimensions": {"radius": 0.8},
                        "variation": 0.4
                    }
                ],
                "tertiary_details": ["texture", "wind_motion"]
            },
            "coral": {
                "primary_form": {
                    "primitive": "ICO_SPHERE",
                    "name": "base",
                    "dimensions": {"radius": 0.3},
                    "variation": 0.5
                },
                "secondary_forms": [
                    {
                        "primitive": "CUBE",
                        "name": "branch",
                        "dimensions": {"size": 0.1},
                        "variation": 0.6
                    }
                ],
                "tertiary_details": ["color", "texture"]
            },
            "empty_crib": {
                "primary_form": {
                    "primitive": "CUBE",
                    "name": "frame",
                    "dimensions": {"width": 1.0, "height": 0.8, "depth": 0.6},
                    "variation": 0.3
                },
                "secondary_forms": [
                    {
                        "primitive": "CYLINDER",
                        "name": "bar",
                        "dimensions": {"radius": 0.02, "height": 0.6},
                        "variation": 0.3
                    }
                ],
                "tertiary_details": ["broken_wood", "dust", "cobwebs"]
            },
            "broken_toy": {
                "primary_form": {
                    "primitive": "SPHERE",
                    "name": "body",
                    "dimensions": {"radius": 0.2},
                    "variation": 0.5
                },
                "secondary_forms": [
                    {
                        "primitive": "CUBE",
                        "name": "fragment",
                        "dimensions": {"size": 0.1},
                        "variation": 0.6
                    }
                ],
                "tertiary_details": ["cracked", "dirty", "faded"]
            },
            "doll": {
                "primary_form": {
                    "primitive": "SPHERE",
                    "name": "head",
                    "dimensions": {"radius": 0.15},
                    "variation": 0.4
                },
                "secondary_forms": [
                    {
                        "primitive": "CYLINDER",
                        "name": "body",
                        "dimensions": {"radius": 0.1, "height": 0.3},
                        "variation": 0.4
                    }
                ],
                "tertiary_details": ["cracked_face", "torn_clothes", "dirty"]
            },
            "shadow": {
                "primary_form": {
                    "primitive": "PLANE",
                    "name": "base",
                    "dimensions": {"width": 2.0, "height": 2.0},
                    "variation": 0.8
                },
                "secondary_forms": [],
                "tertiary_details": ["dark", "transparent", "blurred"]
            },
            "mirror": {
                "primary_form": {
                    "primitive": "CUBE",
                    "name": "frame",
                    "dimensions": {"width": 0.8, "height": 1.2, "depth": 0.1},
                    "variation": 0.2
                },
                "secondary_forms": [],
                "tertiary_details": ["cracked", "foggy", "reflection"]
            }
        }
        return base_decompositions.get(object_name, self._get_default_decomposition(object_name))
    
    def _apply_conceptual_variations(self, decomp: Dict, concept: Dict) -> Dict:
        """Apply conceptual variations to object decomposition"""
        try:
            variation_scale = 1.0
            if concept["mapping"]["composition"]["variation"] == "high":
                variation_scale = 1.5
            elif concept["mapping"]["composition"]["variation"] == "low":
                variation_scale = 0.5
            
            # Adjust variations
            if "variation" in decomp["primary_form"]:
                decomp["primary_form"]["variation"] *= variation_scale
            
            for form in decomp["secondary_forms"]:
                if "variation" in form:
                    form["variation"] *= variation_scale
            
            # Add concept-specific details
            if concept["mood"] in ["joy", "love", "peace"]:
                decomp["tertiary_details"].extend(["glow", "soft_edges"])
            elif concept["mood"] in ["fear", "anger"]:
                decomp["tertiary_details"].extend(["sharp_edges", "dark_shadows"])
            
            return decomp
            
        except Exception as e:
            self.warnings.append(f"Error applying conceptual variations: {str(e)}")
            return decomp
    
    def _load_reference_decompositions(self) -> Dict:
        """Load and parse the reference decompositions from unrefined.json"""
        try:
            with open("addon_blender_gpt/composite_objects/reference/unrefined.json", "r") as f:
                data = json.load(f)
                # Convert the reference format to our internal format
                decompositions = {}
                for obj_name, obj_data in data.items():
                    decompositions[obj_name.lower()] = {
                        "primary_form": {
                            "primitive": obj_data["Primary"]["primitive"],
                            "name": "base",
                            "dimensions": self._get_default_dimensions(obj_data["Primary"]["primitive"]),
                            "variation": 0.3
                        },
                        "secondary_forms": [
                            {
                                "primitive": form["primitive"],
                                "name": f"secondary_{i}",
                                "dimensions": self._get_default_dimensions(form["primitive"]),
                                "variation": 0.3
                            }
                            for i, form in enumerate(obj_data["Secondary"])
                        ],
                        "tertiary_details": obj_data["Tertiary"]
                    }
                return decompositions
        except Exception as e:
            print(f"Warning: Could not load reference decompositions: {e}")
            return {}

    def _get_default_dimensions(self, primitive: str) -> Dict:
        """Get default dimensions for a primitive type"""
        dimensions = {
            "Sphere": {"radius": 1.0},
            "Cube": {"width": 1.0, "height": 1.0, "depth": 1.0},
            "Cylinder": {"radius": 0.5, "height": 1.0},
            "Cone": {"radius": 0.5, "height": 1.0},
            "Torus": {"radius": 1.0, "thickness": 0.2},
            "Plane": {"width": 1.0, "height": 1.0},
            "Icosphere": {"radius": 1.0},
            "Pyramid": {"base": 1.0, "height": 1.0}
        }
        return dimensions.get(primitive, {"size": 1.0}) 